import './App.css';
import Form from "./components/Form";

function App() {
  return (
    <div className="wrapper">
      <h1>Todo List</h1>
      <Form/>
    </div>
  );
}

export default App;
